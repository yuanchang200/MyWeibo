//
//  MyImageView.h
//  MyWeibo
//
//  Created by zn on 2018/11/20.
//  Copyright © 2018年 zn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyImageView : UIImageView

@property (nonatomic,nonatomic) int i;
@property (nonatomic,nonatomic) int j;
@property (nonatomic,nonatomic) NSInteger row;
@property (nonatomic,nonatomic) NSInteger column;
@property (nonatomic,nonatomic) NSInteger count;


@end

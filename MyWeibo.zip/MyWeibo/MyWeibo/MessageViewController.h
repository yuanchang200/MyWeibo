//
//  MessageViewController.h
//  MyWeibo
//
//  Created by zn on 2018/11/21.
//  Copyright © 2018年 zn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITabBarItem *messageTabBarItem;

@end
